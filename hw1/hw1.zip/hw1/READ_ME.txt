matrixSumA.c, matrixSumB.c and matrixSumC.c are all made to sum all elements in a matrix in different ways.
They are named suma, sumb, sumc run by the makefile and initiated with lpthread. They can all be run with "./name size workers".
The default values of all three functions are a size of 10000 and 10 max workers.

pi.c is a function to calculate pi with recursive adaptive quadrature. It is named pi by the makefile and initiated with lpthread and lm.
It can be run with "./pi epsilon workers". Default values are epsilon of 0.000001 and 10 max workers.